﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class DoisNumerosController : Controller
    {
        [HttpGet("DoisNumeros")]
        public string DoisNumeros(double numeroUsuario1, double numeroUsuario2)
        {
            double numero1, numero2;
            numero1 = numeroUsuario1;
            numero2 = numeroUsuario2;

            if (numero1 > numero2)
            {
                return $"O número 1: {numero1} é maior que o número 2: {numero2}";
        
            }
            else if (numero2>numero1)
            {

                return $"O número 2: {numero2} é maior que o número 1: {numero1}";

            }
            else
            {
                return $"O número 1: {numero1} e o número 2: {numero2} são iguais";
            }

        }

    }
}
